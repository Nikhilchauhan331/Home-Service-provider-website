{/* <div class="container">
        <h2>Forgot Password</h2>
        <form action="/forgot-password" method="post">
            <input type="email" name="email" placeholder="Enter your email" required />
            <input type="submit" value="Send Reset Link" />
        </form>
        <a href="/">Back to Login</a>
    </div> */}